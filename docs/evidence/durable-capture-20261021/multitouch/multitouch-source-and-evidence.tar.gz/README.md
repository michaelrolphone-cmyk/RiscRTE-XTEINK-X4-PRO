Original source and technical evidence recovery.

This incremental bundle preserves original commit identities. It requires base 6b7d1abe9b2dcc236f6086d07c0f619244c907cb; obtain that source prerequisite before importing. GitHub capture commits have equivalent source trees but distinct metadata.

Tests are scoped historical observations, not firmware release or hardware acceptance. Failed and blocked logs are retained. Build products and private tracker/account/conversation data are excluded.
